<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Role;

class UserController extends Controller
{
    public function showSignupForm()
    {
        return view('signup');
    }
    public function signup(Request $request){
        $request->validate([
            'username' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',

        ]);

        //user 

        $user = User::create([
          'username' => $request->input('username'),
          'email' => $request->input('email'),
          'password' => Hash::make($request->input('password')),
          'role_id' => 1,       
        ]);
        return redirect()->route('login')->with('success','Account created successfully! Please Log in');
    }
}
