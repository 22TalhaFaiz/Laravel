@foreach($product as $pro)
<p>Product Id: {{$pro->id}}</p>
<p>Product Name: {{$pro->pro_name}}</p>
<p>Category Name: {{optional($pro->category)->cat_name ?? 'No Category'}}</p>
@if($pro->pro_image)

<img src="{{asset('images/' . $pro->pro_image)}}" alt="" width="50">
@else
no Image
@endif
@endforeach