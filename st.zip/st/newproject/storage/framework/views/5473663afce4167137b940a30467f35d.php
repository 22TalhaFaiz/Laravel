
<?php $__env->startSection('mylayout'); ?>

<form action='/products/update' method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" required>
            <label for="cat_id">Category:</label>
            <select name="cat_id" class="form-control" required>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($category ->id == $product->cat_id ? 'selected' : ''); ?>>
                <?php echo e($category->cat_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
        </div>
    
        <label for="name">Product Name:</label>
        <input type="text" name="pro_name" value="<?php echo e($product ->pro_name); ?>" required>
        <br>
        <label for="name">Product Image:</label>
        <input type="file" name="pro_image" required>
        <br>
        <button type="submit">Update Product</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/editproduct.blade.php ENDPATH**/ ?>