<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>Product Id: <?php echo e($pro->id); ?></p>
<p>Product Name: <?php echo e($pro->pro_name); ?></p>
<p>Category Name: <?php echo e(optional($pro->category)->cat_name ?? 'No Category'); ?></p>
<?php if($pro->pro_image): ?>

<img src="<?php echo e(asset('images/' . $pro->pro_image)); ?>" alt="" width="50">
<?php else: ?>
no Image
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/showproduct.blade.php ENDPATH**/ ?>