<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>Product Id: <?php echo e($pro->id); ?></p>
<p>Product Name: <?php echo e($pro->pro_name); ?></p>
<p>Category Name: <?php echo e(optional($pro->category)->cat_name ?? 'No Category'); ?></p>
<?php if($pro->pro_image): ?>

<img src="<?php echo e(asset('images/' . $pro->pro_image)); ?>" alt="" width="50"><br>
<?php else: ?>
no Image
<?php endif; ?>
<a href="/products/<?php echo e($pro->id); ?>/edit">Edit</a>
<form action="<?php echo e(route('deletep',$pro->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete</button>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/showproduct.blade.php ENDPATH**/ ?>