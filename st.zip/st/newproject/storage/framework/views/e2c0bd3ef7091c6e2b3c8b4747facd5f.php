<?php $__env->startSection('mylayout'); ?>

<form action='/insertpro' method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="cat_id">Category:</label>
            <select name="cat_id" class="form-control" required>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->cat_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
        </div>
    
        <label for="name">Product Name:</label>
        <input type="text" name="pro_name" required>
        <br>
        <label for="name">Product Image:</label>
        <input type="file" name="pro_image" required>
        <br>
        <button type="submit">Insert Product</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/insertproduct.blade.php ENDPATH**/ ?>