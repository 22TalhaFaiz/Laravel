<?php $__env->startSection('mylayout'); ?>
<form action='/editcat/update' method="POST" >
    <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($cat->id); ?>" required>
        <label for="name" >Category Name:</label>
        <input type="text" name="name" value="<?php echo e($cat->cat_name); ?>" required>
        <br>
        <button type="submit">Update Category</button>
    </form>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/editcat.blade.php ENDPATH**/ ?>