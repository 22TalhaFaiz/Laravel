<?php $__env->startSection('mylayout'); ?>


<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <p>Category Id: <?php echo e($cat->id); ?></p>
    <p>Category Name <?php echo e($cat->cat_name); ?></p>
    <a href="/editcat/<?php echo e($cat->id); ?>/edit">Edit</a>
    <form action="<?php echo e(route('deletee',$cat->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Delete</button>
    </form>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/showcat.blade.php ENDPATH**/ ?>