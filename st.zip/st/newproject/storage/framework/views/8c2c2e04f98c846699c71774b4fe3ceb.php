
<?php $__env->startSection('mylayout'); ?>

<h1>Welcome </h1>
<a href="<?php echo e(route('create')); ?>">Insert Category</a>
<a href="<?php echo e(route('showcat')); ?>">Show Category</a>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newproject\resources\views/index.blade.php ENDPATH**/ ?>