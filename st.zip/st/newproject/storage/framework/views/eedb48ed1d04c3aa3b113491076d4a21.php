<?php $__env->startSection('mylayout'); ?>

<form action='/insert' method="POST" >
        <?php echo csrf_field(); ?>
        <label for="name">Category Name:</label>
        <input type="text" name="name" required>
        <br>
        <button type="submit">Insert Category</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\st\newproject\resources\views/insertcat.blade.php ENDPATH**/ ?>