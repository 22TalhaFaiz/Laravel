<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;

class ProductController extends Controller
{
    public function insertproduct(){
        $category = Category::all();
        return view('insertproduct',['cat'=>$category]);
    }
    public function insertpro(Request $request)
    {
        // Validations
        $request->validate([
            'pro_name' => 'required|string|max:255',
            'cat_id' => 'required|exists:category,id',
            'pro_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $imageName = time().'.'.$request->pro_image->extension();
        $request->pro_image->move(public_path('images'), $imageName);
    
        // Create new product
     Product::create([
        'pro_name' => $request->input('pro_name') ,
        'cat_id' => $request->input('cat_id') ,
        'pro_image' => $imageName,
     ]);
     return redirect()->route('showproduct');

    }
    public function showproduct()
    {
        $pro = Product::with('category')->get();
        return view('showproduct',['product'=>$pro]);
    }





}

