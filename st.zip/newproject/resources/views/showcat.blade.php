@extends('layout')
@section('mylayout')


@foreach($category as $cat)
    <p>Category Id: {{ $cat->id }}</p>
    <p>Category Name {{ $cat->cat_name }}</p>
    <a href="/editcat/{{ $cat->id }}/edit">Edit</a>
    @endforeach

@endsection